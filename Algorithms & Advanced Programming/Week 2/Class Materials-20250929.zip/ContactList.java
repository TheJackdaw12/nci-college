import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;


class ContactList{

    private final ArrayList <Contact> contacts = new ArrayList <>();

    public void readFile() throws FileNotFoundException{
        
        Contact p = new Contact();
        try{
            Scanner s = new Scanner(new File("C:/Users/olahart/OneDrive - National College of Ireland/Documents/NetBeansProjects/LabWeek2/src/main/java/people.txt"));

            s.useDelimiter(";");
            while (s.hasNext()) {
              
                p.setName(s.next());
                p.setPhone(s.next());
                contacts.add(p);
                p = new Contact();
            }
        }
        catch(FileNotFoundException error){
            System.out.println("error - people.txt not found" + error);
        }
    }

    public ArrayList getContacts(){
        return contacts;
    }


}