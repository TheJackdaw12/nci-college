import java.util.ArrayList;
import java.util.Date;

public class Main {
    public static void main(String[] args) {

        Person Andrew = new Person();
        Andrew.setAge(27);
        Andrew.setName("Andrew");
        Andrew.setDob(new Date(1995, 1, 1));
        Person Sarah = new Person();
        Sarah.setAge(24);
        Sarah.setName("Sarah");
        Sarah.setDob(new Date(1998, 9, 10));
        Person Paul = new Person();
        Paul.setAge(35);
        Paul.setName("Paul");
        Paul.setDob(new Date(1987, 4, 17));
        Person Lisa = new Person();
        Lisa.setAge(25);
        Lisa.setName("Lisa");
        Lisa.setDob(new Date(1997, 5, 21));
        Person Dave = new Person();
        Dave.setAge(30);
        Dave.setName("Dave");
        Dave.setDob(new Date(1992, 8, 19));

        Person[] persons = {
                Andrew,
                Sarah,
                Paul,
                Lisa,
                Dave
        };

        persons[0].getDob().toString();
        System.out.println("Before:");
        for(int i = 0; i < persons.length; i++){
            System.out.println("Person: " + persons[i].getName() + "\tAge: " + persons[i].getAge() + "\tDob: " + persons[i].getDob());
        }

        // Change this to the name of the function that you wish to use to sort the Array.
        SelectionSortByName(persons);

        System.out.println("After");
        for(int i = 0; i < persons.length; i++){
            System.out.println("Person: " + persons[i].getName() + "\tAge: " + persons[i].getAge() + "\tDob: " + persons[i].getDob().getYear() + "/" + persons[i].getDob().getMonth() + "/" + persons[i].getDob().getDate());
        }
    }

    public static void SelectionSortByAge(Person[] persons){
        int minIndex = 0;
        Person temp;
        for(int i = 0; i < persons.length; i++){
            minIndex = i;
            for(int j = i; j < persons.length; j++){
                if(persons[j].getAge() < persons[minIndex].getAge()){
                    minIndex = j;
                }
            }

            if(minIndex != i){
                temp = persons[i];
                persons[i] = persons[minIndex];
                persons[minIndex] = temp;
            }
        }
    }

    public static void SelectionSortByDob(Person[] persons){
        int minIndex = 0;
        Person temp;
        for(int i = 0; i < persons.length; i++){
            minIndex = i;
            for(int j = i; j < persons.length; j++){
                if(persons[j].getDob().compareTo(persons[minIndex].getDob()) > 0){
                    minIndex = j;
                }
            }

            if(minIndex != i){
                temp = persons[i];
                persons[i] = persons[minIndex];
                persons[minIndex] = temp;
            }
        }
    }

    public static void SelectionSortByName(Person[] persons){
        int minIndex = 0;
        Person temp;
        for(int i = 0; i < persons.length; i++){
            minIndex = i;
            for(int j = i; j < persons.length; j++){
                if(persons[j].getName().compareTo(persons[minIndex].getName()) < 0){
                    minIndex = j;
                }
            }

            if(minIndex != i){
                temp = persons[i];
                persons[i] = persons[minIndex];
                persons[minIndex] = temp;
            }
        }
    }
}