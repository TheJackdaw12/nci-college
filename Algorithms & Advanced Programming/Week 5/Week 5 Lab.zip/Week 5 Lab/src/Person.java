import java.util.Date;

class Person{

    private String name;
    private int age;
    private Date dob;

    public Person(){
        name = new String();
        age =0;
    }   

    public void setName(String n){
        name=n;
    }

    public void setAge(int a){
        age=a;
    }

    public String getName(){
        return name;
    }   

    public int getAge(){
        return age;
    }

    public Date getDob(){return dob;}

    public void setDob(Date newDob){dob = newDob;}
}
