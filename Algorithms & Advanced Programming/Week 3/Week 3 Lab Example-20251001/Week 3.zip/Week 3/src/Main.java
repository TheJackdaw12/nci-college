import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Random rand = new Random();

        int n = 10;
        int[] magicNumbers = new int[n];

        for (int i = 0; i < n; i++){
            magicNumbers[i] = rand.nextInt(1, 100);
            System.out.println(magicNumbers[i]);
        }

        Boolean guessIsCorrect = false;
        int guess = 0;

        Scanner scannerObj = new Scanner(System.in);
        while(!guessIsCorrect){
            System.out.println("Please enter your guess to see if you number is MAGIC!!!");

            guess = Integer.parseInt(scannerObj.nextLine());

            int result = checkGuessLiniarly(magicNumbers, guess, 0);
//            System.out.println("Result: " + result);
            if(result != -1) {
                System.out.println("Your number is MAGIC!!!");
                guessIsCorrect = true;
            }else{
                System.out.println("Your number is NOT MAGIC!!!");
            }
        }
    }

    private static int checkGuessLiniarly(int[] magicNumbers, int guess, int guessPosition) {
        int result = 0;
//        System.out.println("Guess posiotn: " + guessPosition);
//        System.out.println("magicnumber.length: " + magicNumbers.length);
        if(guessPosition >= magicNumbers.length-1){
//            System.out.println("I am -1!");
            result = -1;
        }else if(guess == magicNumbers[guessPosition]){
            result = guessPosition;
        }else{
            result = checkGuessLiniarly(magicNumbers, guess, guessPosition+1);
        }

        return result;
    }
}